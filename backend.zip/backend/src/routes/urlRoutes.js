import express from "express";
import { createShortUrl } from "../controller/urlController";
import { redirectFromShortUrl } from "../controller/redirectController";

const router = express.Router();

router.post("/", createShortUrl);
router.get("/", redirectFromShortUrl);

export default router;
